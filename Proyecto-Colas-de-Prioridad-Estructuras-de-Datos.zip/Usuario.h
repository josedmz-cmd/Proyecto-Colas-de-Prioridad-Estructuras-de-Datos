#pragma once
class Usuario
{
};

