#pragma once
class Tiquete
{
};

